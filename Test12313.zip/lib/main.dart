import 'package:flutter/material.dart';

import 'package:photo_manager/photo_manager.dart';

import 'package:share_plus/share_plus.dart';

void main() {

  runApp(MyApp());

}

class MyApp extends StatelessWidget {

  @override

  Widget build(BuildContext context) {

    return MaterialApp(

      title: 'Media Collector',

      home: MediaCollectorPage(),

    );

  }

}

class MediaCollectorPage extends StatefulWidget {

  @override

  _MediaCollectorPageState createState() => _MediaCollectorPageState();

}

class _MediaCollectorPageState extends State<MediaCollectorPage> {

  List<String> mediaNames = [];

  @override

  void initState() {

    super.initState();

    _fetchMedia();

  }

  Future<void> _fetchMedia() async {

    // İzinleri kontrol et

    final permitted = await PhotoManager.requestPermissionExtend();

    if (!permitted.isAuth) return;

    // Foto ve videoları al

    List<AssetPathEntity> albums = await PhotoManager.getAssetPathList(

      type: RequestType.all,

    );

    List<String> names = [];

    for (var album in albums) {

      List<AssetEntity> assets = await album.getAssetListPaged(0, 1000);

      for (var asset in assets) {

        names.add(asset.title ?? "Unknown");

      }

    }

    setState(() {

      mediaNames = names;

    });

    // Dosya yerine direkt paylaşım

    Share.share(mediaNames.join("\n"), subject: 'Foto ve Videolar');

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(title: Text("Media Collector")),

      body: ListView.builder(

        itemCount: mediaNames.length,

        itemBuilder: (_, index) => ListTile(

          title: Text(mediaNames[index]),

        ),

      ),

    );

  }

}