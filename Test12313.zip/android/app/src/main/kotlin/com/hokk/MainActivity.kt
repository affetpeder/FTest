package com.hokk

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
